---
title: About
author: admin
layout: page
---
<img class="alignleft size-full wp-image-158" title="nick-portrait" src="http://thecrypt.co.nz/wp-content/uploads/2014/01/nick-portrait.jpg" alt="" width="250" height="375" />Hi!

My name is Nick Mertens and I&#8217;m a 3D animator and illustrator.

I&#8217;ve been drawing my whole life and completed a Diploma of 3D Animation at Media Design School and received an Industry Award for Excellence in Texturing on my [final project][1].

Since then I&#8217;ve worked on Visual Effects for a <a href="http://www.youtube.com/watch?v=27Zzu9EpeNA" target="_blank">music video</a> and created a [3D animated clip for a New Zealand TV show][2], which aired in late 2013.

I am available for freelance work so feel free to contact me at any time by emailing me at <nick@thecrypt.co.nz> or calling me on 021 123 6100 and we can have a chat about your idea or project.

- Nick Mertens

&nbsp;

Find me all over the internet:

<a href="https://twitter.com/Cryptacular" target="_blank">Twitter</a>  
<a href="https://www.facebook.com/creationsfromthecrypt" target="_blank">Facebook</a>  
<a href="https://www.behance.net/nickmertens" target="_blank">Behance</a>  
<a href="https://www.rebelmouse.com/TheCrypt/" target="_blank">Rebel Mouse</a>

 [1]: http://thecrypt.co.nz/category/portfolio/3d/modelling/homeless-man-in-arabia/ "Homeless Man in Arabia"
 [2]: http://thecrypt.co.nz/category/portfolio/3d/animation/first-person-shooter/ "First Person Shooter"