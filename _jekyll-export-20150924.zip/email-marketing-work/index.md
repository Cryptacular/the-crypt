---
title: Email Marketing Work
author: admin
layout: page
---
**Design**

  * <a href="http://thecrypt.co.nz/wp-content/uploads/2014/04/bespoke-mockup-v3.jpg" target="_blank">Bespoke</a>
  * <a href="http://thecrypt.co.nz/wp-content/uploads/2014/04/hbl-template-mockup.jpg" target="_blank">HBL</a>
  * <a href="http://thecrypt.co.nz/wp-content/uploads/2014/04/open-resource-newsletter-mockup-v4.jpg" target="_blank">Open Resource (newsletter)</a>
  * <a href="http://thecrypt.co.nz/wp-content/uploads/2014/04/pba.jpg" target="_blank">Ponsonby Business Association (long)</a>
  * <a href="http://thecrypt.co.nz/wp-content/uploads/2014/04/pba-short.jpg" target="_blank">Ponsonby Business Association (short)</a>
  * <a href="http://thecrypt.co.nz/wp-content/uploads/2014/04/spike-news-mockup-v1.jpg" target="_blank">Spike News v1</a>
  * <a href="http://thecrypt.co.nz/wp-content/uploads/2014/04/spike-news-mockup-v2.jpg" target="_blank">Spike News v2</a>
  * <a href="http://thecrypt.co.nz/wp-content/uploads/2014/04/turner-hopkins.jpg" target="_blank">Turner Hopkins</a>
  * <a href="http://thecrypt.co.nz/wp-content/uploads/2014/04/world-of-bentley-desktop.jpg" target="_blank">W.O. Bentley</a>

**HTML**

  * <a href="http://thecrypt.co.nz/wp-content/uploads/2014/04/intelligent-ink-invitation.html" target="_blank">Intelligent Ink (invitation)</a>
  * <a href="http://thecrypt.co.nz/wp-content/uploads/2014/04/open-resource-newsletter.html" target="_blank">Open Resource (newsletter)</a>
  * <a href="http://thecrypt.co.nz/wp-content/uploads/2014/04/open-resource-welcome.html" target="_blank">Open Resource (welcome)</a>
  * <a href="http://thecrypt.co.nz/wp-content/uploads/2014/04/scti-responsive.html" target="_blank">Southern Cross Travel Insurance (responsive)</a>
  * <a href="http://thecrypt.co.nz/wp-content/uploads/2014/04/spike-news-responsive.html" target="_blank">Spike News (responsive)</a>
  * <a href="http://thecrypt.co.nz/wp-content/uploads/2014/04/world-of-bentley-responsive.html" target="_blank">W.O. Bentley (responsive)</a>