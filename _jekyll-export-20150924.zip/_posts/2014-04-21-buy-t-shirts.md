---
title: Buy my T-shirts!
author: admin
layout: post
permalink: /category/blog/personal-work/buy-t-shirts/
categories:
  - Personal Work
---
Seeing as I&#8217;ve been working on some T-shirt designs lately, I have just<a href="https://thecrypt.printmighty.co.nz/" target="_blank"> set up an online store</a> where you can purchase some of my designs on T-shirts &#8211; both male and female fits in different sizes and colours.

Currently you can purchase my <a title="Scott Pilgrim vs. Dark Souls" href="http://thecrypt.co.nz/category/portfolio/2d/illustration/scott-pilgrim-vs-dark-souls/" target="_blank">Scott Pilgrim vs. Dark Souls</a> shirts and my <a title="Planet of the Abes" href="http://thecrypt.co.nz/category/portfolio/2d/illustration/planet-abes/" target="_blank">Planet of the Abes</a> shirts and I will add more shirts as time goes on. If you have any requests for previous designs on shirts, just <a title="About" href="http://thecrypt.co.nz/about/" target="_blank">let me know</a> :)

<a href="https://thecrypt.printmighty.co.nz/" target="_blank">Have a look here! →</a>