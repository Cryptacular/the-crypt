---
title: 'BlenderGuru Competition: Characters'
author: admin
layout: post
permalink: /category/blog/blenderguru-competition-characters/
categories:
  - Blog
---
<a href="http://www.blenderguru.com/new-competition-characters/" target="_blank"><img src="http://thecrypt.co.nz/wp-content/uploads/2014/02/centaur-580x435.jpg" alt="" title="Centaur" width="580" height="435" class="aligncenter size-full wp-image-218" /></a>

The great Andrew Price at <a href="http://www.blenderguru.com/" target="_blank">BlenderGuru</a> has launched another competition for Blender users: this time it&#8217;s all about characters.

There are some great prizes and, even if you are not thinking of entering, he&#8217;s posted some amazing inspiration on his competition page.

The deadline is set on the 17th of March (roughly 6 weeks from posting the competition) so get crackin&#8217;!

<a href="http://www.blenderguru.com/new-competition-characters/" target="_blank">Check out the competition here</a>.

[<img src="http://thecrypt.co.nz/wp-content/uploads/2014/02/heavy_knight-580x682.jpg" alt="" title="Heavy Knight" width="580" height="682" class="aligncenter size-full wp-image-217" />][1]

 [1]: http://www.blenderguru.com/new-competition-characters/