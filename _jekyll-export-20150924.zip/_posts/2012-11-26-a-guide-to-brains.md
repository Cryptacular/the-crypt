---
title: A Guide to Brains
author: admin
layout: post
permalink: /category/portfolio/2d/vector/a-guide-to-brains/
categories:
  - Vector
format: image
---
For those of us craving a nice brain salad or perhaps some crispy battered cerebellum, here&#8217;s a guide to brains.

Created in Illustrator.