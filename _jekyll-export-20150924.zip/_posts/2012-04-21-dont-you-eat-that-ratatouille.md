---
title: 'Don&#8217;t You Eat That Ratatouille'
author: admin
layout: post
permalink: /category/portfolio/3d/texturing/dont-you-eat-that-ratatouille/
categories:
  - Texturing
format: image
---
(To see the full HD clip, <a href="http://vimeo.com/40387890" target="_blank">click here</a>)

This is a fan-made model of Pixar&#8217;s Ratatouille kitchen, modelled by Sapna Mondol. I set up the camera, lighting, rearranged some objects and then went on to UV unwrap the necessary objects, add materials and textures to everything and added lighting.