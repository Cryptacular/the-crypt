---
title: 'Drawing in Progress: Mashup time!'
author: admin
layout: post
permalink: /category/blog/drawing-progress-mashup-time/
categories:
  - Blog
  - Personal Work
---
As a big fan of T-shirt designs on <a href="http://www.teefury.com/" target="_blank">Teefury</a> and all the mashups between different IPs (games, movies, TV shows, etc), I got my very own idea for a mashup! It is something I would love to make into a T-shirt design and submit it to <a href="http://www.teefury.com/" target="_blank">Teefury</a> or <a href="https://www.threadless.com/" target="_blank">Threadless</a> or what have you.

Here&#8217;s a bit of a teaser ;)

<blockquote class="twitter-tweet" width="550">
  <p lang="en" dir="ltr">
    Working on a new sketch! <a href="https://twitter.com/hashtag/illustration?src=hash">#illustration</a> <a href="https://twitter.com/hashtag/mashup?src=hash">#mashup</a>. More updates coming later! <a href="http://t.co/bRX7m0CoBg">pic.twitter.com/bRX7m0CoBg</a>
  </p>
  
  <p>
    &mdash; Cryptacular (@Cryptacular) <a href="https://twitter.com/Cryptacular/status/445829129720438784">March 18, 2014</a>
  </p>
</blockquote>



Keep an eye on my <a href="https://twitter.com/Cryptacular" target="_blank">Twitter feed</a> for more updates.