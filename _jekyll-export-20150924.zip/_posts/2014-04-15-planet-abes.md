---
title: Planet of the Abes
author: admin
layout: post
permalink: /category/portfolio/2d/illustration/planet-abes/
categories:
  - Illustration
  - Vector
format: image
---
[<img src="http://thecrypt.co.nz/wp-content/uploads/2014/04/pota-poster-150x150.png" alt="pota-poster" width="150" height="150" class="alignright size-thumbnail wp-image-326" />][1]This T-shirt design illustration is based on a poster for the original movie Planet of the Apes (see the thumbnail on the right)

I was limited to only 6 colours, so I decided to create it in Illustrator. Using a Wacom tablet, I recreated the major shading and swapped out the apes with *Abes*.

Having the image cropped as a rectangle (like the poster) was a bit boring, so I cropped it as a top hat, to add to the general look and feel of Abraham Lincoln.

Hope you like it!

 [1]: http://thecrypt.co.nz/wp-content/uploads/2014/04/pota-poster.png