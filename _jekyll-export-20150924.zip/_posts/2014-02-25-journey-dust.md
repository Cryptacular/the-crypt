---
title: A Journey with Dust
author: admin
layout: post
permalink: /category/blog/journey-dust/
categories:
  - Blog
---
This crowd-funded fantasy short film called Dust has been in development for a number of years now and the visual effects look amazing. The original goals included over 11 days of live action shooting, seven unique CG Creatures and the creation of amazing environments with complex set extensions and mattes.

Have a look at the trailer below (or <a href="http://vimeo.com/85217589" target="_blank">click here</a>) and see for yourself.

&nbsp;



(<a href="http://www.cgsociety.org/index.php/CGSFeatures/CGSFeatureSpecial/dust1" target="_blank">Source</a>)