---
title: Mountain Climbing
author: admin
layout: post
permalink: /category/portfolio/2d/illustration/mountain-climbing/
categories:
  - Illustration
format: image
---
Drawn in pencil on paper first, then imported into Photoshop to clean it up and add colour.

[<img src="http://thecrypt.co.nz/wp-content/uploads/2014/02/mountain-climbing-draft-205x300.jpg" alt="" title="mountain-climbing-draft" width="205" height="300" class="alignnone size-medium wp-image-112" />][1]

 [1]: http://thecrypt.co.nz/wp-content/uploads/2014/02/mountain-climbing-draft.jpg