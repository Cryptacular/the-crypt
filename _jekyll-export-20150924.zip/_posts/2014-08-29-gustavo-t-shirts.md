---
title: Gustavo T-shirts!
author: admin
layout: post
permalink: /category/blog/personal-work/gustavo-t-shirts/
categories:
  - Personal Work
---
T-shirts with my [Gustavo][1] print are now available on my <a href="http://thecrypt.printmighty.co.nz" target="_blank">Print Mighty store</a>!

They&#8217;re available in Mens and Womens styles, sizes XS to XXL, as well as a bunch of different colours, wooh!

While you&#8217;re there, check out some of my other T-shirts too :)

<a href="http://thecrypt.printmighty.co.nz/products/gustavo" target="_blank"><img src="http://thecrypt.co.nz/wp-content/uploads/2014/08/gustavo-mens-150x150.jpg" alt="gustavo-mens" width="150" height="150" class="alignnone size-thumbnail wp-image-379" /></a> <a href="http://thecrypt.printmighty.co.nz/products/gustavo-2" target="_blank"><img src="http://thecrypt.co.nz/wp-content/uploads/2014/08/gustavo-womens-150x150.jpg" alt="gustavo-womens" width="150" height="150" class="alignnone size-thumbnail wp-image-380" /></a>

 [1]: http://thecrypt.co.nz/category/portfolio/2d/illustration/gustavo/ "Gustavo"