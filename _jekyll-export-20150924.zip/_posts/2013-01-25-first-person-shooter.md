---
title: First Person Shooter
author: admin
layout: post
permalink: /category/portfolio/3d/animation/first-person-shooter/
categories:
  - Animation
  - Modelling
  - Texturing
format: image
---
(To see the full HD clip, <a href="http://vimeo.com/58088005" target="_blank">click here</a>)

This short video was made for a New Zealand tv show, where the two main characters are playing a video game. The episode aired in 2013.

It was made in 14 days. Apart from the soldier models, all modelling and texturing was done by me, as well as all the animation, lighting and rendering.

Created in Maya, After Effects and Blender.