---
title: A Nightly Habit
author: admin
layout: post
permalink: /category/portfolio/2d/illustration/a-nightly-habit/
categories:
  - Illustration
format: image
---
As part of testing out my new Wacom Inkling pen, I drew this little guy. I imported the original sketch into Photoshop and added shading and colour.

[<img src="http://thecrypt.co.nz/wp-content/uploads/2014/02/nightly-habit-sketch-278x300.jpg" alt="" title="nightly-habit-sketch" width="278" height="300" class="alignnone size-medium wp-image-114" />][1]

 [1]: http://thecrypt.co.nz/wp-content/uploads/2014/02/nightly-habit-sketch.jpg