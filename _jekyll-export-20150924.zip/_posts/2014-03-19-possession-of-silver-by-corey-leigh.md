---
title: The Possession of Silver by Corey Leigh
author: admin
layout: post
permalink: /category/blog/possession-of-silver-by-corey-leigh/
categories:
  - Blog
---
I&#8217;m so proud to announce that my friend Corey Leigh has written a book that I&#8217;m sure you will love! <a href="http://amzn.com/B00J301WIW" target="_blank">The Possession of Silver</a> is a young adult book full of pirates, treasure and a mysterious island:

> Silver and his crew have stumbled upon an island, frozen in time. It’s an island littered with many a brave or foolish treasure hunter. It’s the kind of island that spooks a pirate, but certainly not Silver. He’s out for riches and nothing is going to stop him, not mutinous pirates, snooty girls, possessive captains, or ghostly apparitions.  
> But Silver will need all his bravado to reach the treasure and to uncover the secrets of the island and he’ll have to decide, is the treasure worth his life?

I&#8217;ve had the privilige to read a few previous versions of it as a proof reader and I can positively say it&#8217;s awesome. It would be so great if you would consider spending the mere $3.99 for this piece of art and <a href="http://amzn.com/B00J301WIW" target="_blank">give it a try</a>!

Don&#8217;t forget to give it a nice rating and share share share! <a href="http://amzn.com/B00J301WIW" target="_blank">Click here to view it on Amazon</a>.

<a href="http://amzn.com/B00J301WIW" target="_blank"><img src="http://thecrypt.co.nz/wp-content/uploads/2014/03/silver-cover-web.jpg" alt="The Possession of Silver" width="300" height="450" class="aligncenter size-full wp-image-279" /></a>