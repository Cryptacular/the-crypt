---
title: 'Animation Appreciation: Nameless Bob 2'
author: admin
layout: post
permalink: /category/blog/animation-appreciation-nameless-bob-2/
categories:
  - Animation Appreciation
  - Blog
---
This excellent bit of 2D animation is the second one in a series. Great work!

<span class='embed-youtube' style='text-align:center; display: block;'></span>

(<a href="https://www.youtube.com/watch?v=yszkSXIlYBs#t=85" target="_blank">Watch it on YouTube</a>)

(Source: <a href="http://www.reddit.com/r/animation/comments/20bbws/nameless_bob_2_part_of_a_series_im_working_on/" target="_blank">reddit.com</a>)