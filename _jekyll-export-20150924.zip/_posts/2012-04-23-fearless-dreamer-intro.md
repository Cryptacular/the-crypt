---
title: Fearless Dreamer Intro
author: admin
layout: post
permalink: /category/portfolio/3d/animation/fearless-dreamer-intro/
categories:
  - Animation
  - Modelling
  - Texturing
  - Visual Effects
format: image
---
(To see the full HD clip, <a href="http://vimeo.com/40842283" target="_blank">click here</a>)

This is an introduction animation I made for a budding new director, Matthew Hopkins, for his short film <a href="http://youtu.be/-Uaruuwlxi0" target="_blank">The Frail</a>. Milky Way panorama in the background is property of ESO and can be found <a href="http://www.eso.org/public/images/eso0932a/" target="_blank">here</a>.