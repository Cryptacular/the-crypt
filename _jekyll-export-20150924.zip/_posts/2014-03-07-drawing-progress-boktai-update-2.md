---
title: 'Drawing in Progress: Boktai (Update #2)'
author: admin
layout: post
permalink: /category/blog/drawing-progress-boktai-update-2/
categories:
  - Blog
  - Personal Work
---
Another quick update: since last time I have started working on the Doom-style lettering at the top. I&#8217;ve also added more lighting from different directions (fill light and rim light as I talked about in the previous post) and fixed up some of the darker bits in the light coming out of the gun.

Have a look:

[<img src="http://thecrypt.co.nz/wp-content/uploads/2014/03/boktai-of-doom-v5-259x300.jpg" alt="boktai of doom v5" width="259" height="300" class="aligncenter size-medium wp-image-263" />][1]

<!--more More after the break -->

I&#8217;ve also started sketching out the elements I want to put around Django, including Otenko (the sunflower, his mentor) and some of the enemies and UI from the game. A photo below:

[<img src="http://thecrypt.co.nz/wp-content/uploads/2014/03/2014-03-06-23.07.49-2-255x300.jpg" alt="Boktai sketch" width="255" height="300" class="aligncenter size-medium wp-image-262" />][2]

Stay tuned!

 [1]: http://thecrypt.co.nz/wp-content/uploads/2014/03/boktai-of-doom-v5.jpg
 [2]: http://thecrypt.co.nz/wp-content/uploads/2014/03/2014-03-06-23.07.49-2.jpg