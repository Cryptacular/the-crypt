---
title: One Pissed Parrot
author: admin
layout: post
permalink: /category/portfolio/2d/illustration/one-pissed-parrot/
categories:
  - Illustration
format: image
---
This is one pissed parrot. Why is he pissed? It might have something to do with those feathers there.

It all started with a few quick sketches, before settling on this one. As you can see in the progress shots below, I started by adding local colours (the base colour of a material not in light or shadow), then shadows, highlights, bounce light, a secondary light source, texture, background and lastly, depth of field.

Hope you like it! Make sure to follow me on <a href="https://twitter.com/Cryptacular" target="_blank">Twitter</a> and <a href="http://instagram.com/creationsfromthecrypt/" target="_blank">Instagram</a> for more art updates :)

[<img class="alignnone size-thumbnail wp-image-417" alt="parrot-stage-01" src="http://thecrypt.co.nz/wp-content/uploads/2014/12/parrot-stage-01-150x150.jpg" width="150" height="150" />][1][<img class="alignnone size-thumbnail wp-image-418" alt="parrot-stage-02" src="http://thecrypt.co.nz/wp-content/uploads/2014/12/parrot-stage-02-150x150.jpg" width="150" height="150" />][2][<img class="alignnone size-thumbnail wp-image-419" alt="parrot-stage-03" src="http://thecrypt.co.nz/wp-content/uploads/2014/12/parrot-stage-03-150x150.jpg" width="150" height="150" />][3][<img class="alignnone size-thumbnail wp-image-420" alt="parrot-stage-04" src="http://thecrypt.co.nz/wp-content/uploads/2014/12/parrot-stage-04-150x150.jpg" width="150" height="150" />][4][<img class="alignnone size-thumbnail wp-image-421" alt="parrot-stage-05" src="http://thecrypt.co.nz/wp-content/uploads/2014/12/parrot-stage-05-150x150.jpg" width="150" height="150" />][5][<img class="alignnone size-thumbnail wp-image-422" alt="parrot-stage-06" src="http://thecrypt.co.nz/wp-content/uploads/2014/12/parrot-stage-06-150x150.jpg" width="150" height="150" />][6][<img class="alignnone size-thumbnail wp-image-423" alt="parrot-stage-07" src="http://thecrypt.co.nz/wp-content/uploads/2014/12/parrot-stage-07-150x150.jpg" width="150" height="150" />][7][<img class="alignnone size-thumbnail wp-image-424" alt="parrot-stage-08" src="http://thecrypt.co.nz/wp-content/uploads/2014/12/parrot-stage-08-150x150.jpg" width="150" height="150" />][8][<img src="http://thecrypt.co.nz/wp-content/uploads/2014/12/parrot-512-150x150.jpg" alt="parrot-512" width="150" height="150" class="alignnone size-thumbnail wp-image-416" />][9]

 [1]: http://thecrypt.co.nz/wp-content/uploads/2014/12/parrot-stage-01.jpg
 [2]: http://thecrypt.co.nz/wp-content/uploads/2014/12/parrot-stage-02.jpg
 [3]: http://thecrypt.co.nz/wp-content/uploads/2014/12/parrot-stage-03.jpg
 [4]: http://thecrypt.co.nz/wp-content/uploads/2014/12/parrot-stage-04.jpg
 [5]: http://thecrypt.co.nz/wp-content/uploads/2014/12/parrot-stage-05.jpg
 [6]: http://thecrypt.co.nz/wp-content/uploads/2014/12/parrot-stage-06.jpg
 [7]: http://thecrypt.co.nz/wp-content/uploads/2014/12/parrot-stage-07.jpg
 [8]: http://thecrypt.co.nz/wp-content/uploads/2014/12/parrot-stage-08.jpg
 [9]: http://thecrypt.co.nz/wp-content/uploads/2014/12/parrot-512.jpg