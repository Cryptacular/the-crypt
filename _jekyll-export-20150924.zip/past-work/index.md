---
title: Past Work
author: admin
layout: page
sharing_disabled:
  - 1
---
<span style="line-height: 1.5em;">Complete builds:</span>

  * The Baby Bag 
      * <a href="http://thebabybag.co.nz" target="_blank">http://thebabybag.co.nz</a>
  * Esquires Indonesia 
      * <a href="http://esquires-static.stable.andsomeideas.com/" target="_blank">http://esquires-static.stable.andsomeideas.com/</a>
      * u: complex
      * pw: simple

Changes to existing:

  * Keystone Trust 
      * <a href="http://www.keystonetrust.org.nz/" target="_blank">http://www.keystonetrust.org.nz/</a>
  * SRAS 
      * <a href="http://www.srasanz.org/" target="_blank">http://www.srasanz.org/</a>
  * FBL 
      * <a href="http://www.fbl.co.nz/" target="_blank">http://www.fbl.co.nz/</a>
  * Green Acres 
      * <a href="http://www.greenacres.co.nz/" target="_blank">http://www.greenacres.co.nz/</a>
  * Marketing Awards 
      * <a href="http://www.everythingmarketing.co.nz/" target="_blank">http://www.everythingmarketing.co.nz/</a>
  * The Briefing 
      * <a href="http://www.the-briefing.co.nz/" target="_blank">http://www.the-briefing.co.nz/</a>
  * Warriors Forever micro site 
      * <a href="http://www.warriorsforever.co.nz/" target="_blank">http://www.warriorsforever.co.nz/</a>
  * DO-IT (Squarespace) 
      * <a href="http://doit-icg.squarespace.com/" target="_blank">http://doit-icg.squarespace.com/</a>
  * Lakes Resort (Squarespace) 
      * <a href="http://www.lakesresortresidents.co.nz/" target="_blank">http://www.lakesresortresidents.co.nz/</a>

Some email marketing work:

  * <a href="http://mail.tangible.net.nz/mail/view/SFAjTvr_u0Oz8AjSVvXJ2g" target="_blank">The Register</a>
  * <a href="http://createsend.com/t/r-46203AE6202D96422540EF23F30FEDED" target="_blank">Image Centre internal newsletter: The Groupie</a>
  * <a href="http://emailnewsletter.keystonetrust.org.nz/t/r-3E5C502978711B882540EF23F30FEDED" target="_blank">Keystone Trust</a>
  * <a href="http://createsend.com/t/r-531A07A51AD4D32C2540EF23F30FEDED" target="_blank">Nosh</a>
  * <a href="http://createsend.com/t/r-E1B3119FC56C639E2540EF23F30FEDED" target="_blank">Toast by Liquorland</a>
  * <a href="http://createsend.com/t/r-8EBE85D45183A7B02540EF23F30FEDED" target="_blank">V8 Super Tourers</a>

&nbsp;