---
title: Feeds
author: admin
layout: page
---
If you&#8217;d like to follow my portfolio and blog via RSS, have a look at the options below.

  * [All portfolio items and blog posts][1]
  * [All portfolio items][2]
  * [All blog posts][3]

You can also follow me on <a href="https://twitter.com/Cryptacular" target="_blank">Twitter</a>.

Thanks for stopping by!

 [1]: http://thecrypt.co.nz/feed/
 [2]: http://thecrypt.co.nz/category/category/portfolio/feed/
 [3]: http://thecrypt.co.nz/category/category/blog/feed/