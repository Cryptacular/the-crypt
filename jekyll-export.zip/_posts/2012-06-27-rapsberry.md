---
title: Rapsberry
author: admin
layout: post
permalink: /category/portfolio/2d/illustration/rapsberry/
categories:
  - Illustration
format: image
---
He&#8217;s the most badass rapper in the world of fruit and vegetable farming.

Drawn and coloured in Photoshop.