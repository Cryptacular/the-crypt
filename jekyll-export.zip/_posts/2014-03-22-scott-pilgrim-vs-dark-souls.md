---
title: Scott Pilgrim vs. Dark Souls
author: admin
layout: post
permalink: /category/portfolio/2d/illustration/scott-pilgrim-vs-dark-souls/
categories:
  - Illustration
  - Vector
format: image
---
It&#8217;s mashup time! As I [teased a few days ago][1], I&#8217;ve been working on a T-shirt design this week. I can now reveal that it&#8217;s a mashup between Scott Pilgrim and Dark Souls.

As it is a mashup of a movie (based on a comic) and a video game, I realise that not everybody will get this reference, so let me explain:

> In Scott Pilgrim vs. The World (the movie), Scott Pilgrim has a crush on Ramona Flowers, but before he can date her he needs to defeat her 7 evil exes. One of them is Roxie Richter, her only evil ex *girlfriend*. When they meet, she says to Scott: &#8220;Prepare to die, obviously.&#8221;
> 
> Dark Souls is a video game, renowned for its difficulty and high probability of players&#8217; characters being killed many times over for the duration of that game. Therefore, they have adapted the tagline &#8220;Prepare To Die.&#8221;

Combining both of those things, I got this! I hope you like it.

I&#8217;ve also submitted the image to <a href="http://www.teefury.com/" target="_blank">TeeFury</a> so who knows, you might be able to buy the T-shirt sometime soon!

 [1]: http://thecrypt.co.nz/category/blog/drawing-progress-mashup-time/ "Drawing in Progress: Mashup time!"