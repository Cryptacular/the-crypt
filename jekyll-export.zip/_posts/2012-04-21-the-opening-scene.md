---
title: The Opening Scene
author: admin
layout: post
permalink: /category/portfolio/3d/animation/the-opening-scene/
categories:
  - Animation
format: image
---
(To see the full HD clip, <a href="http://vimeo.com/36685182" target="_blank">click here</a>)

This animation was made for my final animation assignment at Media Design School. The brief was to animate a character using one of several given scenarios, including &#8216;opening a box.&#8217; As such I chose to base my animation around a burglar in a museum who spots a glowing golden box. What will he find inside?!

Rig by Ingrid Morisson and Roger Feron.