---
title: 'Animation Appreciation: StormJumper'
author: admin
layout: post
permalink: /category/blog/animation-appreciation-stormjumper/
categories:
  - Animation Appreciation
  - Blog
---
*As a planetary storm approaches, a lone shaman manages to avoid disaster.* That&#8217;s the description of this incredible short film, animated by <a href="http://animalcolm.com/" target="_blank">Malcolm Sutherland</a>. It&#8217;s called &#8216;StormJumper&#8217;. You need to watch it.



(<a href="http://vimeo.com/84346114" target="_blank">Click here</a> to view on Vimeo)