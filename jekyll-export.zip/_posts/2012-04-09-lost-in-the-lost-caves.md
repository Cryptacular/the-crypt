---
title: Lost in the Lost Caves
author: admin
layout: post
permalink: /category/portfolio/2d/illustration/lost-in-the-lost-caves/
categories:
  - Illustration
format: image
---
Partially inspired by Smaug of The Hobbit, partially just felt like painting!

Painted in Photoshop.