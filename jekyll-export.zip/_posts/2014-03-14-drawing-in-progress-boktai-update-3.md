---
title: 'Drawing in Progress: Boktai (Update #3)'
author: admin
layout: post
permalink: /category/blog/drawing-in-progress-boktai-update-3/
categories:
  - Blog
  - Personal Work
---
Quick update: I masked out the background, plus I added a layout sketch over the top, to show the elements I&#8217;d like to add next: some enemies from the game and Otenko, his mentor.

<blockquote class="twitter-tweet" width="550">
  <p lang="en" dir="ltr">
    Boktai update, check it! <a href="https://twitter.com/hashtag/illustration?src=hash">#illustration</a> <a href="https://twitter.com/hashtag/boktai?src=hash">#boktai</a> <a href="https://twitter.com/hashtag/doom?src=hash">#doom</a> <a href="http://t.co/7eFxoURPb2">pic.twitter.com/7eFxoURPb2</a>
  </p>
  
  <p>
    &mdash; Cryptacular (@Cryptacular) <a href="https://twitter.com/Cryptacular/status/441883118648041472">March 7, 2014</a>
  </p>
</blockquote>