---
title: Portal Gun
author: admin
layout: post
permalink: /category/portfolio/3d/modelling/portal-gun/
categories:
  - Modelling
format: image
---
I modelled this gun from the Portal game series, based on a blueprint that appeared in one of the promotional videos for Portal 2 (see below screenshot), including the inside parts.

[<img src="http://thecrypt.co.nz/wp-content/uploads/2014/02/portal-blueprint.jpg" alt="" title="portal-blueprint" width="600" height="338" class="alignnone size-full wp-image-115" />][1]

 [1]: http://thecrypt.co.nz/wp-content/uploads/2014/02/portal-blueprint.jpg