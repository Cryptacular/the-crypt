---
title: Invader Ziltoid T-Shirts now available
author: admin
layout: post
permalink: /category/blog/invader-ziltoid-t-shirts-now-available/
categories:
  - Blog
  - Personal Work
---
As of today, you can get your very own [Invader Ziltoid][1] shirt! Available in Mens and Womens styles in a range of sizes and colours! Check them out below:

<a href="http://thecrypt.printmighty.co.nz/" target="_blank"><img src="http://thecrypt.co.nz/wp-content/uploads/2014/10/invader-ziltoid-shirt-mens-150x150.jpg" alt="invader-ziltoid-shirt-mens" width="150" height="150" class="alignnone size-thumbnail wp-image-399" /></a> <a href="http://thecrypt.printmighty.co.nz/" target="_blank"><img src="http://thecrypt.co.nz/wp-content/uploads/2014/10/invader-ziltoid-shirt-womens-150x150.jpg" alt="invader-ziltoid-shirt-womens" width="150" height="150" class="alignnone size-thumbnail wp-image-400" /></a>

While you&#8217;re there, make sure to <a href="https://thecrypt.printmighty.co.nz/" target="_blank">check out my other shirts too</a>.

 [1]: http://thecrypt.co.nz/category/portfolio/invader-ziltoid/ "Invader Ziltoid"