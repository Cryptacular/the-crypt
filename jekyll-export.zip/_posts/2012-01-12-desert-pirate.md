---
title: Desert Pirate
author: admin
layout: post
permalink: /category/portfolio/2d/illustration/desert-pirate/
categories:
  - Illustration
format: image
---
A bit of an experiment with Photoshop brushes.