---
title: The Night Pandas
author: admin
layout: post
permalink: /category/portfolio/2d/illustration/night-pandas/
categories:
  - Illustration
  - Vector
format: image
---
The Night Pandas are an illusive group of merciless pub quizzers, masters of knowledge and deception. They rarely finish in first place, because they know that it&#8217;d be too obvious and risky if they came first all the time.

So anyways, I designed this logo for my pub quiz team. I took some inspiration from Darkwing Duck. I sketched the original design in pencil, then used a Wacom tablet in Illustrator. The background was done in Photoshop.

Hope you like it!