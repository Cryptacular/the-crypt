---
title: A Relatively Deserted Hallway
author: admin
layout: post
permalink: /category/portfolio/3d/texturing/a-relatively-deserted-hallway/
categories:
  - Texturing
format: image
---
(To see the full HD clip, <a href="http://vimeo.com/38715464" target="_blank">click here</a>)

I textured and added lighting to this pre-made 3D model of a hallway (I&#8217;m afraid I can&#8217;t recall who to credit for the modelling).