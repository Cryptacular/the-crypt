---
title: Johnny Social
author: admin
layout: post
permalink: /category/portfolio/2d/illustration/johnny-social/
categories:
  - Illustration
format: image
---
<a href="http://www.johnnysocial.nl/" title="Johnny Social" target="_blank">Johnny Social</a> is a website (in Dutch only at time of writing) that deals with online marketing, including social media, content marketing, websites, apps and newsletters. As part of their brand, they wanted a superhero character which I designed in Photoshop.